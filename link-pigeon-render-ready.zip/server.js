const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: "/ws" });
const rooms = new Map();

app.use(express.static("public"));
app.get("/health", (req,res)=>res.json({ok:true}));
app.get("*", (req,res)=>res.sendFile(require("path").join(__dirname,"public","index.html")));

function code(){
  return crypto.randomBytes(4).toString("base64url").slice(0,6).toUpperCase();
}
function send(ws,msg){ if(ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(msg)); }
function broadcast(room,msg){
  for(const p of room.players) send(p.ws,msg);
}
function clean(roomCode){
  const room=rooms.get(roomCode);
  if(!room)return;
  room.players=room.players.filter(p=>p.ws.readyState===WebSocket.OPEN);
  if(room.players.length===0) rooms.delete(roomCode);
}
function newState(game){
  if(game==="ttt") return {game,b:Array(9).fill(""),turn:"X",winner:null};
  if(game==="c4") return {game,b:Array(42).fill(""),turn:"X",winner:null};
  if(game==="rps") return {game,choices:{},scores:{X:0,O:0},roundDone:false,msg:""};
  return {game,started:false,startAt:0,times:{},scores:{X:0,O:0}};
}

wss.on("connection",(ws)=>{
  let roomCode=null, player=null;

  ws.on("message",(raw)=>{
    let m; try{m=JSON.parse(raw.toString())}catch{return}
    if(m.type==="join"){
      roomCode=String(m.room||"").toUpperCase();
      if(!/^[A-Z0-9]{4,10}$/.test(roomCode)){send(ws,{type:"error",message:"Invalid room"});return}
      let room=rooms.get(roomCode);
      if(!room){
        room={players:[],game:null,state:null,createdAt:Date.now()};
        rooms.set(roomCode,room);
      }
      if(room.players.length>=2){send(ws,{type:"error",message:"Room is full"});return}
      player={ws,name:String(m.name||"Player").slice(0,18),mark:room.players.length===0?"X":"O"};
      room.players.push(player);
      send(ws,{type:"joined",mark:player.mark,room:roomCode,players:room.players.map(p=>p.name),game:room.game,state:room.state});
      broadcast(room,{type:"players",players:room.players.map(p=>p.name)});
      return;
    }
    if(!roomCode)return;
    const room=rooms.get(roomCode); if(!room)return;

    if(m.type==="choose"){
      if(room.players[0]!==player){return}
      room.game=m.game; room.state=newState(m.game);
      broadcast(room,{type:"game",game:room.game,state:room.state});
      return;
    }
    if(m.type==="move"){
      if(room.players.length<2 || !room.state)return;
      applyMove(room,player,m);
      broadcast(room,{type:"state",state:room.state});
      return;
    }
    if(m.type==="rematch"){
      if(room.players[0]!==player)return;
      if(!room.game)return;
      room.state=newState(room.game);
      broadcast(room,{type:"state",state:room.state});
      return;
    }
    if(m.type==="reactionReady"){
      if(room.game!=="reaction")return;
      room.state.ready=(room.state.ready||0)+1;
      if(room.state.ready>=2){
        const delay=1000+Math.floor(Math.random()*2500);
        room.state.started=false; room.state.ready=0;
        setTimeout(()=>{
          if(!rooms.has(roomCode))return;
          const r=rooms.get(roomCode);
          if(!r.state || r.game!=="reaction")return;
          r.state.started=true; r.state.startAt=Date.now();
          broadcast(r,{type:"reactionGo",at:r.state.startAt});
        },delay);
      }
      return;
    }
    if(m.type==="reactionTap"){
      if(room.game!=="reaction" || !room.state.started || room.state.times[player.mark])return;
      const ms=Date.now()-room.state.startAt;
      room.state.times[player.mark]=ms;
      if(Object.keys(room.state.times).length===2){
        const x=room.state.times.X,o=room.state.times.O;
        const winner=x<o?"X":o<x?"O":"D";
        if(winner!=="D")room.state.scores[winner]++;
        room.state.started=false; room.state.winner=winner;
        broadcast(room,{type:"reactionResult",state:room.state});
      }
      return;
    }
  });

  ws.on("close",()=>{
    if(roomCode){
      const room=rooms.get(roomCode);
      if(room){
        room.players=room.players.filter(p=>p.ws!==ws);
        broadcast(room,{type:"players",players:room.players.map(p=>p.name)});
        if(room.players.length===0)rooms.delete(roomCode);
      }
    }
  });
});

function applyMove(room,p,m){
  const s=room.state;
  if(s.game==="ttt"){
    if(s.winner||s.turn!==p.mark||typeof m.i!=="number"||s.b[m.i])return;
    s.b[m.i]=p.mark; checkTTT(s); if(!s.winner)s.turn=s.turn==="X"?"O":"X";
  }else if(s.game==="c4"){
    if(s.winner||s.turn!==p.mark||m.col<0||m.col>6)return;
    for(let r=5;r>=0;r--){const i=r*7+m.col;if(!s.b[i]){s.b[i]=p.mark;break}}
    checkC4(s); if(!s.winner)s.turn=s.turn==="X"?"O":"X";
  }else if(s.game==="rps"){
    if(s.roundDone||!["rock","paper","scissors"].includes(m.choice)||s.choices[p.mark])return;
    s.choices[p.mark]=m.choice;
    if(s.choices.X&&s.choices.O){
      const x=s.choices.X,o=s.choices.O;
      if(x===o)s.msg="Draw";
      else if((x==="rock"&&o==="scissors")||(x==="paper"&&o==="rock")||(x==="scissors"&&o==="paper")){s.scores.X++;s.msg="Player 1 wins";}
      else{s.scores.O++;s.msg="Player 2 wins";}
      s.roundDone=true;
      if(Math.max(s.scores.X,s.scores.O)<2){
        setTimeout(()=>{
          if(!room.state||room.state!==s)return;
          s.choices={};s.roundDone=false;s.msg="";
          broadcast(room,{type:"state",state:s});
        },900);
      }
    }
  }
}
function checkTTT(s){
  for(const w of [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]])
    if(s.b[w[0]]&&w.every(i=>s.b[i]===s.b[w[0]])){s.winner=s.b[w[0]];return}
  if(s.b.every(Boolean))s.winner="D";
}
function checkC4(s){
  for(let r=0;r<6;r++)for(let c=0;c<7;c++){
    const v=s.b[r*7+c]; if(!v)continue;
    for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){
      let ok=true;
      for(let k=1;k<4;k++){const rr=r+dr*k,cc=c+dc*k;if(rr<0||rr>=6||cc<0||cc>=7||s.b[rr*7+cc]!==v)ok=false}
      if(ok){s.winner=v;return}
    }
  }
  if(s.b.every(Boolean))s.winner="D";
}
setInterval(()=>{for(const [code,room] of rooms){for(const p of room.players)if(p.ws.readyState===WebSocket.OPEN)p.ws.ping();if(Date.now()-room.createdAt>6*60*60*1000&&room.players.length===0)rooms.delete(code)}},30000);

const port=process.env.PORT||10000;
server.listen(port,"0.0.0.0",()=>console.log(`Link Pigeon listening on ${port}`));
