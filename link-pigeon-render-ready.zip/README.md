# Link Pigeon — Render-ready

A two-player Game Pigeon-style web app using Express + WebSockets.

## Deploy free on Render
1. Put this folder in a GitHub repository.
2. In Render choose **New → Web Service** and connect the repo.
3. Runtime: Node.
4. Build command: `npm install`
5. Start command: `npm start`
6. Choose the **Free** plan.
7. Deploy.

Render gives the service a free `onrender.com` URL. Open it on iPhone, create a room, and send the room URL to your friend.

The room state is held in server memory, so rooms disappear when the service restarts/spins down. That is intentional for this free prototype; no paid database is required.
